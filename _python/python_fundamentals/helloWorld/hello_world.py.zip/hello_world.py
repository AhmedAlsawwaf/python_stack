print("hello world")
name = "Ahmed"
print("hello",name)
print("hello"+name)
number =24
print("hello",number)
# print("hello"+number)
fav_food1 ="pizza"
fav_food2 ="burger"
print(f"I love {fav_food1} and {fav_food2}")
print("I love {} and {}".format(fav_food1,fav_food2))