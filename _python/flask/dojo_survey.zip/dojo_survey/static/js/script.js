document.querySelector('.back-button').addEventListener('click', function() {
    window.location.reload();
});