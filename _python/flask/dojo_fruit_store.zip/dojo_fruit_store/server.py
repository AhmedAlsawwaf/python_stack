from flask import Flask, render_template, request, redirect,session
from datetime import datetime
app = Flask(__name__)  
app.secret_key ='lmD49}+*dCK#/<qEi"y3c~*A9*[9eeAr4hJz%NXy}kIy~BT|sr=Vq"^vg1on8Y]'
FRUITS_DATA = [
    {'name': 'Apple', 'image': 'apple.png', 'key': 'apple'},
    {'name': 'Blackberry', 'image': 'blackberry.png', 'key': 'blackberry'},
    {'name': 'Raspberry', 'image': 'raspberry.png', 'key': 'raspberry'},
    {'name': 'Strawberry', 'image': 'strawberry.png', 'key': 'strawberry'},
]
@app.route('/')         
def index():
    session.pop('order_data',None)
    return render_template("index.html",fruits=FRUITS_DATA)

@app.route('/checkout', methods=['POST'])
def checkout():
    first_name =request.form.get('first_name','')
    last_name =request.form.get('last_name','')
    quantities={
        fruit['key'] : int(request.form.get(fruit['key'],0))
        for fruit in FRUITS_DATA
    }
    total_fruits = sum(quantities.values())
    session['order_data'] = {
        'first_name' : first_name,
        'last_name' : last_name,
        'student_id' : request.form.get('student_id',''),
        'quantities': quantities,
        'total_fruits' : total_fruits,
        'order_time' : datetime.now().strftime("%B %d %Y %I:%M:%S %p")
    }
    return redirect('confirmation')

@app.route('/confirmation')
def confirmation():
    if 'order_data' not in session:
        return redirect('index')
    return render_template("checkout.html", **session['order_data'])


@app.route('/fruits')         
def fruits():
    return render_template("fruits.html",fruits = FRUITS_DATA)

if __name__=="__main__":   
    app.run(debug=True)   